import test from 'node:test';
import assert from 'node:assert/strict';
import {amount,validate,paymentId,dorms} from '../domain.mjs';
test('ปฏิเสธยอดเงินไม่ถูกต้อง',()=>{for(const v of [-1,'',Infinity,'abc',1.001])assert.throws(()=>amount(v));assert.equal(amount('1000.50'),1000.5);assert.equal(amount(0),0);});
test('ป้องกันฟิลด์สิทธิ์แฝง',()=>{const d=validate('students',{code:'1',name:'ทดสอบ',grade:'ม.1',dorm:dorms[0],role:'master'});assert.equal(d.role,undefined);assert.throws(()=>validate('students',{code:'1',name:'ทดสอบ',grade:'ม.1',dorm:'อื่น'}));});
test('งานล่วงหน้าต้องอยู่ในอนาคต',()=>{assert.throws(()=>validate('tasks',{year:'2569',semester:'1',month:'2026-10',runAt:'2020-01-01',amount:100}));});
test('รหัสยอดเงินแยกตามช่วงเวลา',()=>{assert.notEqual(paymentId('a','2569','1','2026-10'),paymentId('a','2569','2','2026-10'));});
test('จำกัดเวลาใช้งาน',()=>{const s={documentName:'รายงาน',address:'ที่อยู่',documentId:'1',timeout:30,countdown:5};assert.equal(validate('settings',s).timezone,'Asia/Bangkok');assert.throws(()=>validate('settings',{...s,timeout:0}));assert.throws(()=>validate('settings',{...s,countdown:100}));});
